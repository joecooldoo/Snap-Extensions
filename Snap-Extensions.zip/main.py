###############################################SETUP
from __future__ import division
import os
import re
import math
import searchword
from replit import db
from flask_cors import CORS  #get CORS
from flask import Flask, render_template  #get tool to render pages
from scratchclient import ScratchSession as s  #get scratchclient
from datetime import datetime, date

scratch = s("SocialActionsBot",
            os.environ['scratch_password'])  #login to account
app = Flask('app')
CORS(app)

################################################GIBBERISH CLASSIFIER
"""
Gibberish Classifier
Author: ProgramFOX
Licensed under CPOL v1.02: http://www.codeproject.com/info/cpol10.aspx
"""

def split_in_chunks(text, chunk_size):
    chunks = []
    for i in range(0, len(text), chunk_size):
        chunks.append(text[i:i + chunk_size])
    if len(chunks) > 1 and len(chunks[-1]) < 10:
        chunks[-2] += chunks[-1]
        chunks.pop(-1)
    return chunks


def unique_chars_per_chunk_percentage(text, chunk_size):
    chunks = split_in_chunks(text, chunk_size)
    unique_chars_percentages = []
    for chunk in chunks:
        total = len(chunk)
        unique = len(set(chunk))
        unique_chars_percentages.append(unique / total)
    return sum(unique_chars_percentages) / len(unique_chars_percentages) * 100


def vowels_percentage(text):
    vowels = 0
    total = 0
    for c in text:
        if not c.isalpha():
            continue
        total += 1
        if c in "aeiouAEIOU":
            vowels += 1
    if total != 0:
        return vowels / total * 100
    else:
        return 0


def word_to_char_ratio(text):
    chars = len(text)
    words = len([x for x in re.split(r"[\W_]", text) if x.strip() != ""])
    return words / chars * 100


def deviation_score(percentage, lower_bound, upper_bound):
    if percentage < lower_bound:
        return math.log(lower_bound - percentage, lower_bound) * 100
    elif percentage > upper_bound:
        return math.log(percentage - upper_bound, 100 - upper_bound) * 100
    else:
        return 0


def classify(text):
    if text is None or len(text) == 0:
        return 0.0
    ucpcp = unique_chars_per_chunk_percentage(text, 35)
    vp = vowels_percentage(text)
    wtcr = word_to_char_ratio(text)

    ucpcp_dev = max(deviation_score(ucpcp, 45, 50), 1)
    vp_dev = max(deviation_score(vp, 35, 45), 1)
    wtcr_dev = max(deviation_score(wtcr, 15, 20), 1)

    return max((math.log10(ucpcp_dev) + math.log10(vp_dev) +
                math.log10(wtcr_dev)) / 6 * 100, 1)

###############################################HTML
@app.route('/')  #display home
def main():
	print('Home Visited')
	return render_template('home.html')


@app.route('/Cloud')
def cloudhtml():
	print('Cloud Visited')
	return render_template('Cloud.html')


@app.route('/Scratch')
def scratchhtml():
	print('Scratch API Blocks Page Visited')
	return render_template('scratch.html')


###############################################CODE
###############################################CLOUD VARS
@app.route('/set/<randomnum>/<name>/<val>')  #set a cloud variable
def setvar(randomnum, name, val):  #randomnum is there so Snap! caching wont effect the system
	sentence = name
	if not searchword.searchWord(sentence):
		sentence = val
		if not searchword.searchWord(sentence) and (classify(name) < 60):
			db[name] = val
			print('Set A Variable!')
			return render_template('Success.html')
      #render the success page

@app.route(
    '/get/<randomnum>/<name>'
)  #no css for getting the value of a var because you will get all the html of the page instead of the variable
def gt(randomnum, name):
	value = db[name]
	print('Told A Variable!')
	return value


@app.route('/delete/<randomnum>/<name>')  #delete a cloud variable
def dlt(randomnum, name):
	del db[name]
	print('Deleted A Variable!')
	return render_template('Success.html')


@app.route('/all/<username>/<password>/<randomnum>'
           )  #gets all cloud vars; protected by username and password
def all(username, password, randomnum):
	if username in os.environ['adminusernames'] and password in os.environ['adminpasswords'] and not username in os.environ['blacklist'] and not password in os.environ['blacklist']:
		print('Told All Variables!')
		return "▨".join(db.keys())
	else:
		print(
		    'Someone Requested To Get All The Keys, But Entered Invalid Credentials.'
		)
		return ('Invalid Credentials!')


###############################################SCRATCH API STUFF
@app.route('/scratch/var/<projectid>/<var_name>/<randomnum>')
def id(projectid, var_name, randomnum):
	try:
		connection = scratch.create_cloud_connection(projectid)
		print('Requested A Scratch Cloud Variable!')
		return connection.get_cloud_variable(var_name)
	except:
		print('ScratchClient is not working!')
		return "Snap! Extension's  Scratch Connection are not working. Please contact the developer."


###############################################DATES
@app.route('/date/<randomnum>')
def date(randomnum):
	print('Got date!')
	day_of_year = str(datetime.now().timetuple().tm_yday)
	return day_of_year


###############################################REPLACE THING WITH THING
@app.route('/replace/<phrase>/<letter>/<replacement>/<randomnum>')
def snaprplce(phrase, letter, replacement, randomnum):
	print('Replaced Some Text!')
	a = (phrase)
	b = a.split(letter)
	return replacement.join(b)


###############################################LOGIN
@app.route('/login/<username>/<password>/<randomnum>')
def login(username, password, randomnum):
	if username in os.environ['adminusernames'] and password in os.environ['adminpasswords'] and not username in os.environ['blacklist'] and not password in os.environ['blacklist']:
		print('Logged In ' + username + '!')
		return "Valid Credentials!"
	else:
		print('Someone Attempted To Login But Failed!')
		return "Invalid Credentials!"

###############################################SERVER HISTORY
@app.route('/news/<username>/<password>/<randomnum>')
def hist(username, password, randomnum):
  if username in os.environ['adminusernames'] and password in os.environ['adminpasswords']:
    File_object = open(r"news", "r")
    print('Told News!')
    return File_object.read()
###############################################PING RECIEVER
@app.route('/ping')  #for uptimerobot
def ping():
	return ('Pinged!')

###############################################GIBBERISH BLOCK
@app.route('/gibberish/<input>/<randomnum>')
def gibb(input, randomnum):
  if (classify(input) > 60):
    print(input + " is gibberish!")
    return 'true'
  else:
    print(input + " is not gibberish!")
    return 'false'

##############TEST
@app.route('/users/c')
def nothinglol():
  return 'joecooldoo'

###############################################SERVER
app.run(host='0.0.0.0', port=8080)  #start server

#replit database rules:
#50 MB per database (sum of keys and values)
#5,000 keys per database
#1000 bytes per key
#5 MB per value

#############################Who NOT to give admin to:
#Bubgamer07 (Bungamer07 on Scratch))
#OPEN
#OPEN
#OPEN
#OPEN
