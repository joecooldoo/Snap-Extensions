removeWordsTxtFile = open("RemWordDictionary",'r')
tempTxt = removeWordsTxtFile.read()
removeWordsTxtFile.close()

remWordsDic = tempTxt.split('\n')

badWordsTxtFile = open("BadWordsDictionary",'r')
tempTxt = badWordsTxtFile.read()
badWordsTxtFile.close()

badWordsDic = tempTxt.split('\n')



def searchWord(sentence):
  sentence = cleanUpSentence(sentence)

  for i in badWordsDic:
    if boyer_moore(i, sentence):
      return True
  return False

def cleanUpSentence(sentence = ""):
  sentence = sentence.lower()

  listedSentece = []
  for i in sentence:
    listedSentece.append(i)
    
  for l in remWordsDic:
    while l in listedSentece:
      for i in listedSentece:
          if l == i:
            listedSentece.remove(i)
  
  finalSentence =""

  for i in listedSentece:
    finalSentence += i
  
  return finalSentence

def boyer_moore(pattern, text):

    M = len(pattern)
    N = len(text)
    i = 0

    while i <= N-M:
        j = M - 1
        while j >= 0:

            if pattern[j] != text[i+j]:
              move = find(pattern, text[i + M - 1])
              break

            j = j - 1
            
        if j == -1:
            return True
        else:
            i += move

    return False

def find(pattern, char):
    for i in range(len(pattern)-2, -1, -1):
        if pattern[i] == char:
            return len(pattern) -i -1
            
    return len(pattern)


